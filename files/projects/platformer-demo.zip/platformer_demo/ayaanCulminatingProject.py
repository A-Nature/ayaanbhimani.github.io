import os
import sys
import pygame
from pygame.locals import *

pygame.init()


BASE_DIR = os.path.dirname(os.path.abspath(__file__))


def asset(*parts):
    return os.path.join(BASE_DIR, *parts)


width = 1168
height = 704

gameWindow = pygame.display.set_mode((width, height))
timer = pygame.time.Clock()

font = pygame.font.Font(asset('font', 'Grand9K Pixel.ttf'), 60)

gameDifficulty = 0


playerWalkSpeed = 6
playerAnimFramesPerStep = 5
enemyAnimFramesPerStep = 8

white = (255, 255, 255)


def loadImage(*parts, size=None):
    img = pygame.image.load(asset(*parts)).convert_alpha()
    if size:
        img = pygame.transform.scale(img, size)
    return img


ladders = loadImage('levels', 'level1', 'levelOneLadders.png', size=(width, height))
foreground = loadImage('levels', 'level1', 'levelOneForeground.png', size=(width, height))
level = loadImage('levels', 'level1', 'levelOneInteractable.png', size=(width, height))
background = loadImage('levels', 'level1', 'levelOneBackground.png', size=(width, height))


froggyStillLeft = loadImage('sprites', 'froggy', 'still', 'froggyStill.png', size=(40, 40))
froggyStillRight = pygame.transform.flip(froggyStillLeft, True, False)

froggyWalkLeft = [loadImage('sprites', 'froggy', 'walk', 'froggyWalk' + str(i) + '.png', size=(40, 40)) for i in range(1, 5)]
froggyWalkRight = [pygame.transform.flip(img, True, False) for img in froggyWalkLeft]

froggyJumpLeft = loadImage('sprites', 'froggy', 'jump', 'froggyJump6.png', size=(40, 40))
froggyJumpRight = pygame.transform.flip(froggyJumpLeft, True, False)


crocWalkLeft = [loadImage('sprites', 'croc', 'walk', 'crocWalk' + str(i) + '.png', size=(53, 40)) for i in range(1, 5)]
crocWalkRight = [pygame.transform.flip(img, True, False) for img in crocWalkLeft]


def drawCroc(x, y, facingLeft, animFrame):
    if facingLeft:
        gameWindow.blit(crocWalkLeft[animFrame % 4], (x, y))
    else:
        gameWindow.blit(crocWalkRight[animFrame % 4], (x, y))


def quitGame():
    pygame.quit()
    sys.exit()


def playGame():


    playerOneX = 8
    playerOneY = 122
    playerOneHeight = 24
    playerOneWidth = 24
    playerOneSpeed = 0
    playerOneDeaths = 0
    playerOneFacingLeft = False
    playerOneIsGrounded = True


    gravity = 0.9
    playerOneJumpVelocity = 0


    enemyOneX = 980
    enemyOneY = 280

    enemyTwoX = 483
    enemyTwoY = 90

    enemyThreeX = 193
    enemyThreeY = 120


    enemyOneFacingLeft = False
    enemyTwoFacingLeft = False
    enemyThreeFacingLeft = False


    if gameDifficulty == 0:
        enemySpeed = 2
    elif gameDifficulty == 1:
        enemySpeed = 3
    else:
        enemySpeed = 4


    levelOneBlockOne = Rect(0, 160, 66, 128)
    levelOneBlockTwo = Rect(63, 192, 96, 180)
    levelOneBlockThree = Rect(192, 160, 96, 32)
    levelOneBlockFour = Rect(480, 128, 95, 95)
    levelOneBlockFive = Rect(609, 256, 95, 32)
    levelOneBlockSix = Rect(863, 320, 161, 32)
    levelOneBlockSeven = Rect(1061, 288, 24, 32)
    levelOneBlockEight = Rect(1120, 256, 28, 32)

    levelOnePlatformOne = Rect(352, 159, 62, 13)
    levelOnePlatformTwo = Rect(1025, 191, 95, 12)
    levelOnePlatformThree = Rect(913, 161, 55, 13)
    levelOnePlatformFour = Rect(960, 97, 47, 11)

    levelOneLadderOne = Rect(1120, 173, 32, 95)
    levelOneLadderTwo = Rect(934, 82, 18, 75)


    gamePlaying = True

    frame = 0

    while gamePlaying:

        frame += 1
        gravity = 0.9


        if enemyOneFacingLeft:
            enemyOneX -= enemySpeed
            if enemyOneX < 840:
                enemyOneFacingLeft = False
        else:
            enemyOneX += enemySpeed
            if enemyOneX > 980:
                enemyOneFacingLeft = True


        if gameDifficulty >= 1:
            if enemyTwoFacingLeft:
                enemyTwoX -= enemySpeed
                if enemyTwoX < 463:
                    enemyTwoFacingLeft = False
            else:
                enemyTwoX += enemySpeed
                if enemyTwoX > 535:
                    enemyTwoFacingLeft = True


        if gameDifficulty == 2:
            if enemyThreeFacingLeft:
                enemyThreeX -= enemySpeed
                if enemyThreeX < 181:
                    enemyThreeFacingLeft = False
            else:
                enemyThreeX += enemySpeed
                if enemyThreeX > 248:
                    enemyThreeFacingLeft = True


        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                quitGame()

            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_w and playerOneIsGrounded:
                    playerOneJumpVelocity = -12
                    playerOneIsGrounded = False

                if event.key == pygame.K_ESCAPE:
                    gamePlaying = False


        keys = pygame.key.get_pressed()
        playerOneSpeed = 0
        if keys[K_d]:
            playerOneSpeed += playerWalkSpeed
        if keys[K_a]:
            playerOneSpeed -= playerWalkSpeed

        if playerOneSpeed > 0:
            playerOneFacingLeft = False
        elif playerOneSpeed < 0:
            playerOneFacingLeft = True


        playerOneX += playerOneSpeed


        playerOneJumpVelocity += gravity
        if playerOneJumpVelocity > 13:
            playerOneJumpVelocity = 13
        if not playerOneIsGrounded:
            playerOneY += playerOneJumpVelocity
        playerOneIsGrounded = False


        playerOneRect = Rect(playerOneX + 10, playerOneY + 15, playerOneWidth, playerOneHeight)


        enemyOneRect = Rect(enemyOneX + 8, enemyOneY + 16, 35, 22)
        enemyTwoRect = Rect(enemyTwoX + 8, enemyTwoY + 16, 35, 22)
        enemyThreeRect = Rect(enemyThreeX + 8, enemyThreeY + 16, 35, 22)

        if playerOneRect.colliderect(levelOneLadderOne):
            gravity = 0
            playerOneJumpVelocity = 0

        if playerOneRect.colliderect(levelOneBlockOne):
            if playerOneX < 56 and playerOneY < 140:
                playerOneY = 122
                playerOneIsGrounded = True
            elif playerOneY > 130:
                playerOneX = 54

        if playerOneRect.colliderect(levelOneBlockTwo):
            if playerOneX < 159 and playerOneY < 180:
                playerOneY = 154
                playerOneIsGrounded = True
            elif playerOneX < 192 and playerOneY > 164:
                playerOneX = 150

        if playerOneRect.colliderect(levelOneBlockThree):
            if playerOneX > 170 and playerOneY < 152:
                playerOneY = 122
                playerOneIsGrounded = True
            elif playerOneY > 164 and playerOneX < 192:
                playerOneX = 160
            elif playerOneY > 160 and playerOneX > 286:
                playerOneX = 254

        if playerOneRect.colliderect(levelOnePlatformOne):
            if playerOneX > 330 and playerOneY < 152:
                playerOneY = 122
                playerOneIsGrounded = True

        if playerOneRect.colliderect(levelOneBlockFour):
            if playerOneY < 126:
                playerOneY = 90
                playerOneIsGrounded = True
            elif playerOneX < 480 and playerOneY > 120:
                playerOneX = 448
            elif playerOneX > 540 and playerOneY > 120:
                playerOneX = 570

        if playerOneRect.colliderect(levelOneBlockFive):
            if playerOneX > 587 and playerOneY > 216:
                playerOneY = 218
                playerOneJumpVelocity = 0
                playerOneIsGrounded = True

        if playerOneRect.colliderect(levelOneBlockSix):
            if playerOneX > 840 and playerOneY < 320:
                playerOneY = 282
                playerOneIsGrounded = True

        if playerOneRect.colliderect(levelOneBlockSeven):
            if playerOneY < 270:
                playerOneY = 250
                playerOneIsGrounded = True
            elif playerOneY > 250 and playerOneX < 1045:
                playerOneX = 1023
            elif playerOneY > 250 and playerOneX > 1100:
                playerOneX = 1100

        if playerOneRect.colliderect(levelOneBlockEight):
            if playerOneY < 248:
                playerOneY = 218
                playerOneIsGrounded = True
            elif playerOneY > 234 and playerOneX < 1122:
                playerOneX = 1100
            elif playerOneY > 234 and playerOneX > 1148:
                playerOneX = 1152

        if playerOneRect.colliderect(levelOnePlatformTwo):
            if playerOneY < 160 and playerOneX < 1105:
                playerOneY = 153
                playerOneIsGrounded = True
            elif playerOneY > 180:
                playerOneY = 195
                playerOneJumpVelocity = 0

        if playerOneRect.colliderect(levelOnePlatformThree):
            if playerOneX < 1000 and playerOneX > 890:
                playerOneY = 123
                playerOneIsGrounded = True
            elif playerOneX > 1000:
                playerOneX = 1000

        if playerOneRect.colliderect(levelOnePlatformFour):
            if playerOneX > 950 and playerOneY < 98:
                playerOneY = 59
                playerOneIsGrounded = True
            elif 90 < playerOneY <= 104 and playerOneX > 943:
                playerOneY = 106
                playerOneJumpVelocity = 0


        if playerOneRect.colliderect(levelOneLadderOne) or playerOneRect.colliderect(levelOneLadderTwo):
            playerOneJumpVelocity = gravity
            if keys[K_w]:
                playerOneJumpVelocity -= 4
            elif keys[K_s]:
                playerOneJumpVelocity += 4


        died = False

        if playerOneRect.colliderect(enemyOneRect):
            died = True

        if gameDifficulty >= 1 and playerOneRect.colliderect(enemyTwoRect):
            died = True

        if gameDifficulty == 2 and playerOneRect.colliderect(enemyThreeRect):
            died = True


        if playerOneY > 320:
            died = True

        if died:
            playerOneDeaths += 1
            playerOneX = 8
            playerOneY = 122
            playerOneJumpVelocity = 0


        if playerOneX < -16:
            playerOneX = -14

        if playerOneX > 1156:
            playerOneX = 1153

        playerAnimFrame = frame // playerAnimFramesPerStep
        enemyAnimFrame = frame // enemyAnimFramesPerStep


        gameWindow.fill(white)

        gameWindow.blit(background, (0, 0))
        gameWindow.blit(level, (0, 0))
        gameWindow.blit(ladders, (0, 0))

        drawCroc(enemyOneX, enemyOneY, enemyOneFacingLeft, enemyAnimFrame)

        if gameDifficulty >= 1:
            drawCroc(enemyTwoX, enemyTwoY, enemyTwoFacingLeft, enemyAnimFrame)

        if gameDifficulty == 2:
            drawCroc(enemyThreeX, enemyThreeY, enemyThreeFacingLeft, enemyAnimFrame)

        if playerOneIsGrounded:
            if playerOneSpeed == 0:
                if playerOneFacingLeft:
                    playerImage = froggyStillLeft
                else:
                    playerImage = froggyStillRight
            else:
                if playerOneFacingLeft:
                    playerImage = froggyWalkLeft[playerAnimFrame % 4]
                else:
                    playerImage = froggyWalkRight[playerAnimFrame % 4]
        else:

            if playerOneFacingLeft:
                playerImage = froggyJumpLeft
            else:
                playerImage = froggyJumpRight

        gameWindow.blit(playerImage, (playerOneX, playerOneY))

        gameWindow.blit(foreground, (0, 0))

        pygame.display.update()


        timer.tick(60)


color = (152, 194, 151)
colorLight = (87, 89, 130)
colorDark = (46, 47, 71)


textPlay = font.render('Play Game', True, color)
textQuit = font.render('Quit', True, color)
textDifficulty = font.render('Difficulty:', True, color)
textEasy = font.render('Easy', True, color)
textMedium = font.render('Medium', True, color)
textHard = font.render('Hard', True, color)


playRect = Rect(398, 212, 345, 80)
quitRect = Rect(398, 316, 345, 80)
easyRect = Rect(194, 515, 181, 80)
mediumRect = Rect(467, 515, 228, 80)
hardRect = Rect(774, 515, 170, 80)

while True:

    for ev in pygame.event.get():

        if ev.type == pygame.QUIT:
            quitGame()


        if ev.type == pygame.MOUSEBUTTONDOWN and ev.button == 1:
            if playRect.collidepoint(ev.pos):
                playGame()

            elif quitRect.collidepoint(ev.pos):
                quitGame()

            elif easyRect.collidepoint(ev.pos):
                gameDifficulty = 0

            elif mediumRect.collidepoint(ev.pos):
                gameDifficulty = 1

            elif hardRect.collidepoint(ev.pos):
                gameDifficulty = 2

    gameWindow.fill((8, 82, 0))

    mouse = pygame.mouse.get_pos()


    for rect, selected in [(playRect, False),
                           (quitRect, False),
                           (easyRect, gameDifficulty == 0),
                           (mediumRect, gameDifficulty == 1),
                           (hardRect, gameDifficulty == 2)]:
        if rect.collidepoint(mouse) or selected:
            pygame.draw.rect(gameWindow, colorLight, rect)
        else:
            pygame.draw.rect(gameWindow, colorDark, rect)


    gameWindow.blit(textPlay, (420, 200))
    gameWindow.blit(textQuit, (420, 300))
    gameWindow.blit(textDifficulty, (420, 400))
    gameWindow.blit(textEasy, (200, 500))
    gameWindow.blit(textMedium, (480, 500))
    gameWindow.blit(textHard, (780, 500))

    pygame.display.update()