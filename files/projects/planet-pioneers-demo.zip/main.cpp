// credit for background music: https://www.youtube.com/watch?v=KIO5uLWkL8Y

#include <iostream>
#include <raylib.h>
#include <vector>
#include <cstdlib> // for random numbers
#include <ctime>   // to seed the random number generator

using namespace std;

// struct for a particle
struct Particle {
    Vector2 position; // position of the particle
    Vector2 velocity; // velocity of the particle
    float radius; // radius of the particle
    Color color; // color of the particle
    float lifeTime; // remaining life of the particle
};

// commonly used button struct
struct Button{
    Rectangle buttonInfo; // the rect
    Color displayButtonColor; // current display colour
    string description; // description
    bool isPurchased = false; // is it currently owned?
    int buttonCost; // how much would it cost
    int planetRequirement; // what level on planets does it need
    int amountBought = 0; // currently owned amount
    int maxAvailable; // the max amount you can buy
    Button(Rectangle buttonInfo, Color displayButtonColor, bool isPurchased, int buttonCost, int maxAvailable, string description, int planetRequirement){ // constructor
        this -> buttonInfo = buttonInfo;
        this -> displayButtonColor = displayButtonColor;
        this -> buttonCost = buttonCost;
        this -> isPurchased = isPurchased;
        this -> maxAvailable = maxAvailable;
        this -> description = description;
        this -> planetRequirement = planetRequirement;
    }
};

struct Planet{
    Rectangle planetInfo; // rect containing size
    Texture2D planetTexture; // texture
    bool isPurchased = false; // is the planet owned?
    float planetCost; // how much does it cost
    int planetRequirement; // do you need any previous planets?
    string description; // text description
    
    Planet(Rectangle planetInfo, Texture2D planetTexture, int planetCost, string description, int planetRequirement){ //constructor
        this -> planetInfo = planetInfo;
        this -> planetTexture = planetTexture;
        this -> planetCost = planetCost;
        this -> description = description;
        this -> planetRequirement = planetRequirement;
    }
};

// to display a planet, calls in a data struct planet, the coordinates of it, the current player balance, mouse position, the name of the planet, how much it upgrades and the level needed
void displayPlanet(Planet planet, Vector2 planetCords, float balance, Vector2 mousePosition, string name, float upgradeFactor, int planetLevel, Texture2D upgradeTextureOne, Texture2D upgradeTextureTwo, Button upgradeOne, Button upgradeTwo){
   // if it is owned, it is drawn in full colour
    if (planet.isPurchased == true){
        DrawTextureRec(planet.planetTexture, planet.planetInfo, planetCords, WHITE);
    }

    // if you can afford it, it has some colour
    else if (planet.isPurchased == false and balance >= planet.planetCost){
        DrawTextureRec(planet.planetTexture, planet.planetInfo, planetCords, (Color){59, 59, 59, 255});
    }

    // if you cant even Afford it, it has very dark colour
    else if (planet.isPurchased == false and balance < planet.planetCost){
        DrawTextureRec(planet.planetTexture, planet.planetInfo, planetCords, (Color){37, 37, 37, 255});
    }

    // if the mouse is currently hovering over the planets main coordinates (works as a square but is mostly accurate)
    if (mousePosition.x > planetCords.x and mousePosition.x < planetCords.x + planet.planetInfo.width and mousePosition.y > planetCords.y and mousePosition.y < planetCords.y + planet.planetInfo.height){
        string requirementString; // can be formatted to be useful in different situations
        DrawRectangle(planetCords.x - 40, planetCords.y - 120, 180, 110, (Color){74, 74, 74, 255}); // main box
        DrawLine(planetCords.x - 40, planetCords.y - 120, planetCords.x + 140, planetCords.y - 120, (Color){173, 173, 173, 255}); // border line 1
        DrawLine(planetCords.x + 140, planetCords.y - 120, planetCords.x + 140, planetCords.y - 10, (Color){173, 173, 173, 255}); // another border line
        DrawLine(planetCords.x - 40, planetCords.y - 120, planetCords.x - 40, planetCords.y - 10, (Color){173, 173, 173, 255}); // border line
        DrawLine(planetCords.x - 40, planetCords.y - 10, planetCords.x + 140, planetCords.y - 10, (Color){173, 173, 173, 255}); // border line
        DrawText(TextFormat("%s", name.c_str()), planetCords.x - 38, planetCords.y - 118, 25, WHITE); // name of planet
        DrawText(TextFormat("%s", planet.description.c_str()), planetCords.x - 38, planetCords.y - 93, 9, WHITE); // description of planet
        DrawLine(planetCords.x - 40, planetCords.y - 44, planetCords.x + 140, planetCords.y - 44, (Color){173, 173, 173, 255}); // border line
        DrawText(TextFormat("Added Income: %0.1f SD/sec", upgradeFactor), planetCords.x - 38, planetCords.y - 21, 10, WHITE); // how much is upgrades
        

        // if the planet isnt bought, it says how much is costs. if it is bought, it will just say its purchased
        if (planet.isPurchased == false){
            DrawText(TextFormat("Cost: %0.1f", planet.planetCost), planetCords.x - 38, planetCords.y - 32, 10, WHITE);

            // if the planet requirement is bigger than what you own, it will determine what planet you need and output it
            if (planet.planetRequirement > planetLevel){
                if (planet.planetRequirement == 1){
                    requirementString = "Mars";
                }
                if (planet.planetRequirement == 2){
                    requirementString = "Doughdor";
                }
                DrawText(TextFormat("Status: Requires %s", requirementString.c_str()), planetCords.x - 38, planetCords.y - 43, 10, WHITE);
            }

            // if you arent rich enough, it tells you how much for you need
            else if (planet.planetCost > balance){
                DrawText(TextFormat("Status: Requires %0.0f More SD", planet.planetCost - balance), planetCords.x - 38, planetCords.y - 43, 10, WHITE);
            }

            // if you can purchase it, it makes it clear
            else{
                DrawText(TextFormat("Status: Purchasable", planet.planetCost - balance), planetCords.x - 38, planetCords.y - 43, 10, WHITE);
            }
        }

        else{
            DrawText(TextFormat("Status: Purchased"), planetCords.x - 38, planetCords.y - 32, 10, WHITE);
        }

    }
    
    //draws little upgrade icons as they are purhcased more and more. if one is owned, one is showed. if half of the max is owned, two are showed. if the max is owned, three are showed
    if (upgradeOne.amountBought > 0){
        DrawTextureRec(upgradeTextureOne, {0, 0, 50, 50}, {planetCords.x - 1, planetCords.y - 20}, WHITE);
    }

    if (upgradeOne.amountBought >= upgradeOne.maxAvailable / 2){
        DrawTextureRec(upgradeTextureOne, {0, 0, 50, 50}, {planetCords.x - 3, planetCords.y + 5}, WHITE);
    }

    if (upgradeOne.amountBought == upgradeOne.maxAvailable){
        DrawTextureRec(upgradeTextureOne, {0, 0, 50, 50}, {planetCords.x - 1, planetCords.y + 39}, WHITE);
    }

    if (upgradeTwo.amountBought > 0){
        DrawTextureRec(upgradeTextureTwo, {0, 0, 50, 50}, {planetCords.x + 50, planetCords.y - 20}, WHITE);
    }

    if (upgradeTwo.amountBought >= upgradeTwo.maxAvailable / 2){
        DrawTextureRec(upgradeTextureTwo, {0, 0, 50, 50}, {planetCords.x + 52, planetCords.y + 5}, WHITE);
    }

    if (upgradeTwo.amountBought == upgradeTwo.maxAvailable){
        DrawTextureRec(upgradeTextureTwo, {0, 0, 50, 50}, {planetCords.x + 50, planetCords.y + 39}, WHITE);
    }
}

// function to show a button, calls a button data struct, its string name, the top y cordinate, the upgrade factor, if it makes money per click/per second, and how big the title should be
void displayButton(Button button, string buttonName, int yCordinate, float upgradeFactor, string clickOrSecond, int titleSize){
    DrawRectangleRec(button.buttonInfo, button.displayButtonColor); // main rectangle
    DrawText(TextFormat("%s", buttonName.c_str()), 1555, yCordinate, titleSize, (Color){94, 100, 110, 255}); // button name (upgrade name)
    DrawText(TextFormat("Cost: %d Stardust", button.buttonCost), 1750, yCordinate, 12, (Color){94, 100, 110, 255}); // how much is costs
    DrawText(TextFormat("Owned: %d/%d", button.amountBought, button.maxAvailable), 1750, yCordinate + 12, 12, (Color){94, 100, 110, 255}); // how many you own and the maximum
    DrawText(TextFormat("+%0.1f Stardust/%s", upgradeFactor, clickOrSecond.c_str()), 1750, yCordinate + 24, 12, (Color){94, 100, 110, 255}); // the upgrade factor info
    DrawText(TextFormat("%s", button.description.c_str()), 1555, yCordinate + 38, 15, (Color){94, 100, 110, 255}); // the short button description
    if (button.isPurchased == true){
        DrawLine(1550, yCordinate, 1920, yCordinate + 100, RED); // if they bought the max of this button, then put a red line to indicate that
    }
}

// used to check if an upgrade is bought. calls the button, balance and factor that changes by reference.
void checkForUpgrade(Button &button, float &balance, float &changingFactor, float upgradeFactor, Vector2 mousePosition, int planetLevel){
    // checks if the click was on the spot
    if (CheckCollisionCircleRec(mousePosition, 5, button.buttonInfo)){
        // if youre allowed to buy it then...
        if (button.isPurchased == false and balance >= button.buttonCost and planetLevel >= button.planetRequirement){
            button.displayButtonColor = (Color){148, 148, 148, 255}; // change the button colour to the click-down colour
            balance -= button.buttonCost; // subtract the cost from the balance
            button.buttonCost *= 1.2; // increase the price by a multiplying amount
            changingFactor += upgradeFactor; // change the factor (add more SD per second or click)
            button.amountBought += 1; // change how many is bought
            if (button.amountBought == button.maxAvailable){
                button.isPurchased = true; // if they now own the max, then mark it as true
            }
        }

        // if you cant buy it but it isnt maxed, display red for a second
        else if(button.isPurchased == false){
            button.displayButtonColor = (Color){99, 0, 0, 255};
        }
    }
}

// checks for planet purchase, self explanatory. changes info about balance, changing factor, planet and level so passed by reference
void checkForPlanetPurchase(Planet &planet, Vector2 planetCords, float &balance, float &changingFactor, int &planetLevel, float upgradeFactor, Vector2 mousePosition){
    Rectangle tempRectangle = {planetCords.x, planetCords.y, planet.planetInfo.width, planet.planetInfo.height}; // makes a temp rectangle since the rectangle stores in Planet does not contain coordinates
    // if they click the planet
    if (CheckCollisionCircleRec(mousePosition, 5, tempRectangle)){
        // makes sure theyre allowed to buy it
        if (planet.isPurchased == false and balance >= planet.planetCost and planetLevel >= planet.planetRequirement){
            balance -= planet.planetCost; // removes the cost from your balance
            changingFactor += upgradeFactor; // changes the factor by the upgrade amount
            planet.isPurchased = true; // marks planet as bought
            planetLevel += 1; // makes planet level higher
        }
    }
}

int main (){
    // sets screen size to fit
    const int SCREEN_WIDTH = 1920;
    const int SCREEN_HEIGHT = 1080;

    float stardustBalance = 0; // users balance
    float stardustPassiveFactor = 0; // how much they make per second
    float stardustClickFactor = 1; // and how much per click
    int secondsToCollect = 1; // the frequency of passive collection
    int currentPlanetLevel = 0; // the level of planets they own
    
    // given code by mr smith
    double timerStart = GetTime(); // gets time at start
    double timerEnd = GetTime(); // and at end
    double timeSinceLastCollect = timerEnd - timerStart; // then gets difference

    Vector2 mousePos = GetMousePosition(); // where mouse is right now

    InitWindow(SCREEN_WIDTH, SCREEN_HEIGHT, "Planet Pioneers"); // makes window with custom name
    InitAudioDevice();
    SetTargetFPS(30); // the target fps

    // loads custom textures
    Texture2D drillTexture = LoadTexture("sprites/drill.png"); 
    Texture2D farmTexture = LoadTexture("sprites/farm.png");
    Texture2D solarTexture = LoadTexture("sprites/solar.png");
    Texture2D labTexture = LoadTexture("sprites/research.png");
    Texture2D milkTexture = LoadTexture("sprites/milk.png");
    Texture2D cookiecropTexture = LoadTexture("sprites/cookiecrop.png");
    Texture2D fruitTexture = LoadTexture("sprites/fruit.png");
    Texture2D mineTexture = LoadTexture("sprites/mine.png");
    Texture2D background = LoadTexture("sprites/bg.png"); 
    
    Sound clickSound = LoadSound("sounds/click.wav"); // loads click sound effect
    SetSoundVolume(clickSound, 0.5); // sets volume as said in website

    Music music = LoadMusicStream("sounds/bg.wav");
    PlayMusicStream(music);
    
    // vector of particles and an iterator to delete
    vector <Particle> particles;
    vector <Particle>::iterator it;

    // setting up the planets
    Planet moon = Planet({0, 0, 100, 100}, LoadTexture("sprites/moon.png"), 0, "Bare, rocky and desolate, this is\nthe moon that has orbited our \nEarth for billions of years.\nAn icon of our history.", 0);
    moon.isPurchased = true; // moon is owned by default so it is set as owned
    Planet mars = Planet({0, 0, 100, 100}, LoadTexture("sprites/mars.png"), 1500, "Nicknamed 'The Red Planet', Mars\ngets itsunique colour from \noxidized iron. Theories\nsuggest life existed here!", 0);
    Planet doughdor = Planet({0, 0, 100, 100}, LoadTexture("sprites/cookieplanet.png"), 8000, "Discovered by the legendary\nHamza Dableh, Doughdor has\nmilk rivers and cookie trees!\nTalk about the milky way!", 1);
    Planet danielLand = Planet({0, 0, 100, 100}, LoadTexture("sprites/jungleplanet.png"), 74000, "Astronaut Daniel Costache\nfound this eerie jungle planet.\nStrange stone ruins and thick\nfoliage, what could it all mean...", 2);

    // setting up all the buttons 
    Button moonDrill = Button({1550, 115, 370, 100}, WHITE, false, 15, 50, "High-tech drill that extracts\nvaluable resources from deep\ninside of the moon. Use with caution.", 0);
    Button moonFarm = Button({1550, 230, 370, 100}, WHITE, false, 20, 30, "These farms can artifically produce\noxygen on the moon, allowing them to\ngrow fresh produce for selling.", 0);
    Button marsSolar = Button({1550, 370, 370, 100}, (Color){255, 165, 133, 255}, false, 100, 30, "A solar panel designed for\nharvesting the powerful energy of\nthe sun.", 1);
    Button marsLab = Button({1550, 485, 370, 100}, (Color){255, 165, 133, 255}, false, 200, 25, "With the most cutting-edge biology\nequipment, these labs research past\nlife forms that may have lived here!", 1);
    Button doughMilk = Button({1550, 625, 370, 100}, (Color){255, 218, 179, 255}, false, 900, 40, "These facilities harvest the fresh\nmilk straight from the Great Milk\nRiver!", 2);
    Button doughFarm = Button({1550, 740, 370, 100}, (Color){255, 218, 179, 255}, false, 750, 15, "Cookie crops make fresh cookies,\nvery harvestable and profitable!", 2);
    Button jungleFruit = Button({1550, 880, 370, 100}, (Color){122, 166, 121, 255}, false, 5000, 40, "The tropical fruits of Danieland\nare super tasty!\nAn irresistable buy!", 3);
    Button jungleMine = Button({1550, 995, 370, 100}, (Color){122, 166, 121, 255}, false, 4000, 50, "The deep caves and underground\ncivilizations hold many\nvaluble minerals for mining!", 3);
    

    while (WindowShouldClose() == false){
        UpdateMusicStream(music); // update music
        mousePos = GetMousePosition(); // current mouse position

        timerEnd = GetTime();
        timeSinceLastCollect = timerEnd - timerStart; // finds time differencer

        if (timeSinceLastCollect > secondsToCollect){
            stardustBalance += stardustPassiveFactor; // adds passive factor if its time
            timerStart += secondsToCollect;
        }

        if (IsMouseButtonPressed(MOUSE_BUTTON_LEFT)){ // triggered on a mouse click (left)
            // used this code at start, unused now
            // mousePos = GetMousePosition();
            // cout << "X: " << mousePos.x << "Y: " << mousePos.y << "\n";

            // if player clicks in space, give them money based on click factor
            if (CheckCollisionCircleRec(mousePos, 5, {0, 80, 1550, 1000})){
                stardustBalance += stardustClickFactor;
                for (int i = 0; i < 24; i++) {
                    Particle particle;
                    particle.position = mousePos;
                    particle.velocity = {(float)(rand() % 400 - 200) / 100, (float)(rand() % 400 - 200) / 100 }; // random velocity (-1 to 1)
                    particle.radius = 3; // small size
                    particle.color = {(unsigned char)(rand() % 256), (unsigned char)(rand() % 256), (unsigned char)(rand() % 256), 255 }; // random color
                    particle.lifeTime = 2; // 2 second lifetime
                    particles.push_back(particle); // add to the vector
                }
                PlaySound(clickSound);
            }

            // checks for every possible upgrade
            checkForUpgrade(moonDrill, stardustBalance, stardustPassiveFactor, 0.6, mousePos, currentPlanetLevel);
            checkForUpgrade(moonFarm, stardustBalance, stardustClickFactor, 0.8, mousePos, currentPlanetLevel);
            checkForUpgrade(marsSolar, stardustBalance, stardustPassiveFactor, 3, mousePos, currentPlanetLevel);
            checkForUpgrade(marsLab, stardustBalance, stardustClickFactor, 5, mousePos, currentPlanetLevel);
            checkForUpgrade(doughMilk, stardustBalance, stardustPassiveFactor, 13, mousePos, currentPlanetLevel);
            checkForUpgrade(doughFarm, stardustBalance, stardustClickFactor, 17, mousePos, currentPlanetLevel);
            checkForUpgrade(jungleFruit, stardustBalance, stardustPassiveFactor, 57, mousePos, currentPlanetLevel);
            checkForUpgrade(jungleMine, stardustBalance, stardustClickFactor, 63, mousePos, currentPlanetLevel);

            // checks if they bought a planet
            checkForPlanetPurchase(mars, (Vector2){500, 700}, stardustBalance, stardustPassiveFactor, currentPlanetLevel, 5, mousePos);
            checkForPlanetPurchase(doughdor, (Vector2){600,280}, stardustBalance, stardustPassiveFactor, currentPlanetLevel, 21, mousePos);
            checkForPlanetPurchase(danielLand, (Vector2){1248,560}, stardustBalance, stardustPassiveFactor, currentPlanetLevel, 99, mousePos);
        }

        if (IsMouseButtonUp(MOUSE_BUTTON_LEFT)){// when mouse is released

            // if a button can still be bought, then change its colour back to the default from the button-down colour
            if (moonDrill.isPurchased == false){ 
                moonDrill.displayButtonColor = WHITE;
            }
            if (moonFarm.isPurchased == false){ 
                moonFarm.displayButtonColor = WHITE;
            }

            if (marsSolar.isPurchased == false){
                marsSolar.displayButtonColor = (Color){255, 165, 133, 255};
            }

            if (marsLab.isPurchased == false){
                marsLab.displayButtonColor = (Color){255, 165, 133, 255};
            }

            if (doughMilk.isPurchased == false){
                doughMilk.displayButtonColor = (Color){255, 218, 179, 255};
            }

            if (doughFarm.isPurchased == false){
                doughFarm.displayButtonColor = (Color){255, 218, 179, 255};
            }

            if (jungleFruit.isPurchased == false){
                jungleFruit.displayButtonColor = (Color){122, 166, 121, 255};
            }

            if (jungleMine.isPurchased == false){
                jungleMine.displayButtonColor = (Color){122, 166, 121, 255};
            }
        }

        for (int i = 0; i < particles.size(); i++) {
            particles[i].position.x += particles[i].velocity.x; // makes velocity change position
            particles[i].position.y += particles[i].velocity.y; // same but for y 
            particles[i].lifeTime -= GetFrameTime(); // updates lifetime

            // fade the particle out
            if (particles[i].lifeTime > 0){
                particles[i].color.a = (unsigned char)(255 * (particles[i].lifeTime / 2.0f));
            }

            if (particles[i].lifeTime == 0){
                it = particles.begin();
                it ++;
                particles.erase(it);
            }
        }

        // starts to draw
        BeginDrawing();
            ClearBackground(BLACK);
            DrawTextureRec(background, {0, 0, 1550, 1000}, (Vector2){0, 80}, (Color){46, 46, 46, 255});

            for (Particle particle : particles) { // for loop vector type
                DrawCircleV(particle.position, particle.radius, particle.color); // draws circle based on position, the radius and the colour for that particle.
            }

            //drawing upgrade tab
            DrawRectangle(1550, 0, 370, 1080, (Color){74, 74, 74, 255}); 
            DrawText(TextFormat("Upgrades:"), 1570, 20, 68, WHITE);
            DrawText(TextFormat("Requires Mars"), 1552, 345, 20, Color{184, 33, 13, 255});
            DrawText(TextFormat("Requires Doughdor"), 1552, 600, 20, Color{255, 156, 51, 255});
            DrawText(TextFormat("Requires Danieland"), 1552, 855, 20, Color{4, 163, 0, 255});
            DrawRectangle(1550, 100, 370, 5, WHITE);

            displayButton(moonDrill, "Moon Drill", 115, 0.6, "sec", 32);
            DrawTextureRec(drillTexture, {0, 0, 50, 50}, (Vector2){1860, 160}, WHITE);
            displayButton(moonFarm, "Moon Farm", 230, 0.8, "click", 32);
            DrawTextureRec(farmTexture, {0, 0, 50, 50}, (Vector2){1860, 275}, WHITE);

            displayButton(marsSolar, "Solar Panel", 370, 3, "sec", 32);
            DrawTextureRec(solarTexture, {0, 0, 50, 50}, (Vector2){1860, 415}, WHITE);
            displayButton(marsLab, "Martian Lab", 485, 5, "click", 32);
            DrawTextureRec(labTexture, {0, 0, 50, 50}, (Vector2){1860, 530}, WHITE);

            displayButton(doughMilk, "Milk Harvester", 625, 13, "sec", 26);
            DrawTextureRec(milkTexture, {0, 0, 50, 50}, (Vector2){1860, 670}, WHITE);
            displayButton(doughFarm, "Cookie Farm", 740, 17, "click", 30);
            DrawTextureRec(cookiecropTexture, {0, 0, 50, 50}, (Vector2){1860, 785}, WHITE);

            displayButton(jungleFruit, "Fruit Farm", 880, 57, "sec", 32);
            DrawTextureRec(fruitTexture, {0, 0, 50, 50}, (Vector2){1860, 925}, WHITE);
            displayButton(jungleMine, "Mining Station", 995, 63, "click", 28);
            DrawTextureRec(mineTexture, {0, 0, 50, 50}, (Vector2){1860, 1040}, WHITE);
            
            //top tab
            DrawRectangle(0 ,0, 1550, 80, (Color){74, 74, 74, 255});
            DrawLine(0, 80, 1550, 80, (Color){173, 173, 173, 255});
            DrawLine(1550, 0, 1550, 1080, (Color){173, 173, 173, 255});

            DrawText(TextFormat("Stardust Balance (SD): %0.1f", stardustBalance), 10, 15, 40, SKYBLUE);
            DrawText(TextFormat("Stardust/Second: %0.1f", stardustPassiveFactor), 10, 55, 20, SKYBLUE);
            DrawText(TextFormat("Stardust/Click: %0.1f", stardustClickFactor), 300, 55, 20, SKYBLUE);
            DrawText("Click In Space To Make Stardust!", 5, 90, 20, SKYBLUE);

            displayPlanet(moon, (Vector2){150, 300}, stardustBalance, mousePos, "The Moon", 0, currentPlanetLevel, drillTexture, farmTexture, moonDrill, moonFarm);
            displayPlanet(mars, (Vector2){500, 700}, stardustBalance, mousePos, "Mars", 5, currentPlanetLevel, solarTexture, labTexture, marsSolar, marsLab);
            displayPlanet(doughdor, (Vector2){600, 280}, stardustBalance, mousePos, "Doughdor", 21, currentPlanetLevel, milkTexture, cookiecropTexture, doughMilk, doughFarm);
            displayPlanet(danielLand, (Vector2){1248, 560}, stardustBalance, mousePos, "Danieland", 99, currentPlanetLevel, fruitTexture, mineTexture, jungleFruit, jungleMine);

            

        EndDrawing();
  
    }

    //unloading sounds + textures
    UnloadMusicStream(music);
    UnloadSound(clickSound);
    UnloadTexture(moon.planetTexture);  
    UnloadTexture(mars.planetTexture); 
    UnloadTexture(doughdor.planetTexture); 
    UnloadTexture(danielLand.planetTexture); 
    UnloadTexture(background); 
    UnloadTexture(drillTexture);
    UnloadTexture(farmTexture);
    UnloadTexture(solarTexture);
    UnloadTexture(labTexture);
    UnloadTexture(milkTexture); 
    UnloadTexture(cookiecropTexture);
    UnloadTexture(fruitTexture);
    UnloadTexture(mineTexture);   

    //closing stuff
    CloseAudioDevice();
    CloseWindow();
}

